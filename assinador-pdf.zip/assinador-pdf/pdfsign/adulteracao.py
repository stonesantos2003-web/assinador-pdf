"""Funcionalidade 4 — utilitário para ADULTERAR um PDF já assinado (apenas para demonstrar a detecção)."""
from __future__ import annotations

import re
from pathlib import Path


class ErroAdulteracao(Exception):
    pass


def adulterar_texto(entrada, saida, de: str, para: str) -> str:
    """Troca um texto por outro de MESMO tamanho dentro da área assinada (ex.: valor de contrato)."""
    if len(de) != len(para):
        raise ErroAdulteracao("Os textos devem ter o mesmo tamanho para não deslocar o arquivo.")
    dados = Path(entrada).read_bytes()
    pos = dados.find(de.encode("latin-1"))
    if pos < 0:
        raise ErroAdulteracao(f"Texto '{de}' não encontrado (o conteúdo do PDF pode estar comprimido; use o modo 'byte').")
    Path(saida).write_bytes(dados[:pos] + para.encode("latin-1") + dados[pos + len(de):])
    return f"Texto '{de}' substituído por '{para}' no byte {pos}."


def adulterar_byte(entrada, saida) -> str:
    """Inverte um bit de um byte no meio da área assinada."""
    dados = bytearray(Path(entrada).read_bytes())
    m = re.search(rb"/ByteRange\s*\[\s*0\s+(\d+)\s", bytes(dados))
    limite = int(m.group(1)) if m else len(dados)
    pos = limite // 2
    dados[pos] ^= 0x01
    Path(saida).write_bytes(bytes(dados))
    return f"Um bit do byte {pos} foi invertido."


def anexar_dados(entrada, saida) -> str:
    """Acrescenta conteúdo ao final do arquivo (simula uma edição/revisão feita após a assinatura)."""
    dados = Path(entrada).read_bytes()
    extra = b"\n% conteudo acrescentado apos a assinatura\n"
    Path(saida).write_bytes(dados + extra)
    return f"{len(extra)} bytes acrescentados ao final do arquivo."
