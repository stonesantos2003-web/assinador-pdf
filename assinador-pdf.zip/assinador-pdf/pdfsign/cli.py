"""Interface de linha de comando (subcomandos) e menu interativo."""
from __future__ import annotations

import argparse
import getpass
import json
import os
import sys
from dataclasses import asdict
from pathlib import Path

from . import __version__
from .adulteracao import ErroAdulteracao, adulterar_byte, adulterar_texto, anexar_dados
from .assinatura import ErroAssinatura, assinar_pdf
from .certificado import (DadosTitular, ErroCertificado, carregar_certificado, carregar_pkcs12,
                          gerar_e_exportar)
from .validacao import ResultadoAssinatura, validar_pdf

ROTULO_INTEGRIDADE = {
    "integro": "ÍNTEGRO — o documento não foi alterado desde a assinatura",
    "alterado_apos_assinatura": "ALTERADO APÓS A ASSINATURA — há conteúdo acrescentado depois da área assinada",
    "conteudo_alterado": "CONTEÚDO ALTERADO — o hash do documento não confere com o que foi assinado",
    "assinatura_invalida": "ASSINATURA CORROMPIDA — a estrutura/assinatura criptográfica não confere",
    "indeterminada": "INDETERMINADA — não foi possível verificar",
}
ROTULO_CONFIANCA = {
    "confiavel": "CONFIÁVEL — a cadeia chega a uma raiz informada como confiável",
    "autoassinado": "AUTOASSINADO — certificado emitido por ele mesmo, sem cadeia de confiança reconhecida",
    "cadeia_desconhecida": "CADEIA DE CONFIANÇA NÃO RECONHECIDA — o emissor não é conhecido/confiável",
    "indeterminada": "INDETERMINADA",
}


# ------------------------------------------------------------------ utilidades
def obter_senha(confirmar: bool = False, prompt: str = "Senha do certificado (.p12): ") -> str:
    senha = os.environ.get("PDFSIGN_SENHA")
    if senha:
        return senha
    senha = getpass.getpass(prompt)
    if confirmar and senha != getpass.getpass("Repita a senha: "):
        raise ErroCertificado("As senhas não conferem.")
    return senha


def escolher_arquivo(titulo: str, tipos) -> str:
    """Abre uma janela de seleção de arquivo (tkinter); se indisponível, pede o caminho no terminal."""
    try:
        import tkinter as tk
        from tkinter import filedialog
        raiz = tk.Tk()
        raiz.withdraw()
        raiz.attributes("-topmost", True)
        caminho = filedialog.askopenfilename(title=titulo, filetypes=tipos)
        raiz.destroy()
        if caminho:
            return caminho
    except Exception:
        pass
    return input(f"{titulo} (caminho do arquivo): ").strip().strip('"')


def _sufixo(caminho: str, sufixo: str) -> str:
    p = Path(caminho)
    return str(p.with_name(p.stem + sufixo + p.suffix))


# ------------------------------------------------------------------ apresentação
def imprimir_relatorio(caminho: str, resultados: list[ResultadoAssinatura]) -> int:
    """Imprime o relatório. Devolve o código de saída (0 = tudo ok, 1 = inválida/alterada, 2 = sem assinaturas)."""
    print(f"\nArquivo: {caminho}")
    if not resultados:
        print("Nenhuma assinatura digital encontrada neste documento.")
        return 2
    print(f"Assinaturas encontradas: {len(resultados)}")
    codigo = 0
    for r in resultados:
        print("\n" + "=" * 78)
        print(f" ASSINATURA #{r.indice}")
        print("=" * 78)
        if r.certificado:
            c = r.certificado
            print("Certificado do signatário")
            print(f"  Titular ......: {c.titular}")
            print(f"  Emissor ......: {c.emissor}")
            print(f"  Nº de série ..: {c.serie}")
            print(f"  Validade .....: {c.valido_de[:19]} até {c.valido_ate[:19]} (UTC)")
            tam = f" {c.tamanho_chave} bits" if c.tamanho_chave else ""
            print(f"  Chave pública : {c.algoritmo_chave}{tam}")
            print(f"  Usos da chave : {', '.join(c.usos_chave) or '—'}")
            print(f"  SHA-256 ......: {c.sha256}")
        print("\nDados da assinatura")
        print(f"  Formato ......: {r.subfiltro or '—'}")
        print(f"  Hash .........: {r.hash_algoritmo or '—'}")
        print(f"  Data/hora ....: {r.data_assinatura or '—'}")
        if r.motivo:
            print(f"  Motivo .......: {r.motivo}")
        print(f"  ByteRange ....: {r.byte_range}")

        print("\nResultado")
        if r.resumo_hash_confere is not None:
            print(f"  [1] Hash do documento confere com o assinado? ... {'SIM' if r.resumo_hash_confere else 'NÃO'}")
        if r.assinatura_confere is not None:
            print(f"  [2] Assinatura confere com a chave pública? ..... {'SIM' if r.assinatura_confere else 'NÃO'}")
        print(f"  ► ASSINATURA CRIPTOGRAFICAMENTE: {'VÁLIDA' if r.assinatura_valida else 'INVÁLIDA'}")
        print(f"  ► INTEGRIDADE DO DOCUMENTO .....: {ROTULO_INTEGRIDADE[r.integridade]}")
        if r.bytes_apos_assinatura and r.integridade == "alterado_apos_assinatura":
            print(f"      ({r.bytes_apos_assinatura} bytes após o fim da área assinada)")
        print(f"  ► CERTIFICADO ..................: {ROTULO_CONFIANCA[r.confianca]}")
        if r.cadeia:
            print(f"      Cadeia: {'  →  '.join(r.cadeia)}")
        for a in r.avisos:
            print(f"  ! Aviso: {a}")
        for e in r.erros:
            print(f"  ✗ Erro: {e}")
        if not r.assinatura_valida or r.integridade != "integro":
            codigo = 1
    print()
    return codigo


# ------------------------------------------------------------------ comandos
def cmd_gerar(args) -> int:
    senha = obter_senha(confirmar=True, prompt="Defina uma senha para proteger a chave privada: ")
    titular = DadosTitular(args.nome, args.org, args.unidade, args.pais, args.estado, args.cidade, args.email)
    prefixo = args.prefixo or args.nome.strip().lower().replace(" ", "_")
    crt, p12, cert = gerar_e_exportar(titular, args.bits, args.dias, args.pasta, prefixo, senha)
    print(f"Par de chaves RSA de {args.bits} bits gerado.")
    print(f"Certificado X.509 autoassinado (válido por {args.dias} dias).")
    print(f"  Certificado público (compartilhável) : {crt}")
    print(f"  Chave privada + certificado (.p12)   : {p12}   <-- NÃO publique este arquivo!")
    return 0


def cmd_assinar(args) -> int:
    senha = obter_senha()
    chave, cert = carregar_pkcs12(args.certificado, senha)
    saida = args.saida or _sufixo(args.pdf, "_assinado")
    info = assinar_pdf(args.pdf, saida, chave, cert, args.motivo or "", args.local or "")
    print(f"PDF assinado com sucesso: {saida}")
    print(f"  Campo de assinatura: {info['campo']}  |  PKCS#7: {info['tamanho_pkcs7']} bytes  |  ByteRange: {info['byte_range']}")
    return 0


def _carregar_raizes(caminhos):
    return [carregar_certificado(c) for c in (caminhos or [])]


def cmd_validar(args) -> int:
    resultados = validar_pdf(args.pdf, _carregar_raizes(args.confiar))
    if args.json:
        print(json.dumps([asdict(r) for r in resultados], indent=2, ensure_ascii=False, default=str))
        if not resultados:
            return 2
        return 0 if all(r.assinatura_valida and r.integridade == "integro" for r in resultados) else 1
    return imprimir_relatorio(args.pdf, resultados)


def cmd_adulterar(args) -> int:
    saida = args.saida or _sufixo(args.pdf, "_adulterado")
    if args.modo == "texto":
        if not args.de or args.para is None:
            raise ErroAdulteracao("No modo 'texto' informe --de e --para (mesmo tamanho).")
        msg = adulterar_texto(args.pdf, saida, args.de, args.para)
    elif args.modo == "byte":
        msg = adulterar_byte(args.pdf, saida)
    else:
        msg = anexar_dados(args.pdf, saida)
    print(f"{msg}\nArquivo adulterado gravado em: {saida}")
    return 0


# ------------------------------------------------------------------ menu interativo
def menu() -> int:
    ultimo_assinado = None
    while True:
        print("\n=== Assinador e Validador de PDF (X.509 / PKCS#7) ===")
        print(" 1) Gerar certificado digital (RSA + X.509 autoassinado)")
        print(" 2) Assinar um PDF")
        print(" 3) Validar assinaturas de um PDF")
        print(" 4) Adulterar um PDF assinado (para testar a integridade)")
        print(" 0) Sair")
        op = input("Opção: ").strip()
        try:
            if op == "1":
                nome = input("Nome do titular (CN): ").strip()
                org = input("Organização (opcional): ").strip()
                email = input("E-mail (opcional): ").strip()
                pais = input("País [BR]: ").strip() or "BR"
                bits = int(input("Tamanho da chave RSA em bits [2048]: ").strip() or 2048)
                dias = int(input("Validade em dias [365]: ").strip() or 365)
                pasta = input("Pasta de saída [certificados]: ").strip() or "certificados"
                ns = argparse.Namespace(nome=nome, org=org, unidade="", pais=pais, estado="", cidade="",
                                        email=email, bits=bits, dias=dias, pasta=pasta, prefixo=None)
                cmd_gerar(ns)
            elif op == "2":
                pdf = escolher_arquivo("Selecione o PDF", [("PDF", "*.pdf")])
                p12 = escolher_arquivo("Selecione o certificado (.p12)", [("PKCS#12", "*.p12 *.pfx")])
                motivo = input("Motivo da assinatura (opcional): ").strip()
                local = input("Local (opcional): ").strip()
                ns = argparse.Namespace(pdf=pdf, certificado=p12, saida=None, motivo=motivo, local=local)
                cmd_assinar(ns)
                ultimo_assinado = _sufixo(pdf, "_assinado")
            elif op == "3":
                pdf = escolher_arquivo("Selecione o PDF assinado", [("PDF", "*.pdf")])
                crt = input("Certificado confiável (.crt) para validar a cadeia [Enter = nenhum]: ").strip()
                imprimir_relatorio(pdf, validar_pdf(pdf, _carregar_raizes([crt] if crt else [])))
            elif op == "4":
                pdf = escolher_arquivo("Selecione o PDF assinado a adulterar", [("PDF", "*.pdf")])
                print(" a) trocar um texto  b) inverter um bit  c) acrescentar dados ao final")
                m = input("Modo [a/b/c]: ").strip().lower()
                if m == "a":
                    ns = argparse.Namespace(pdf=pdf, saida=None, modo="texto",
                                            de=input("Texto original: "), para=input("Novo texto (mesmo tamanho): "))
                else:
                    ns = argparse.Namespace(pdf=pdf, saida=None, modo="byte" if m == "b" else "anexar", de=None, para=None)
                cmd_adulterar(ns)
            elif op == "0":
                return 0
            else:
                print("Opção inválida.")
        except (ErroCertificado, ErroAssinatura, ErroAdulteracao, ValueError, OSError) as e:
            print(f"\nErro: {e}")
        except (KeyboardInterrupt, EOFError):
            print()
            return 0


# ------------------------------------------------------------------ parser
def criar_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="main.py", description="Assinatura e validação digital de PDFs.")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = p.add_subparsers(dest="comando")

    g = sub.add_parser("gerar-certificado", help="gera chave RSA e certificado X.509 autoassinado")
    g.add_argument("--nome", required=True, help="nome do titular (CN)")
    g.add_argument("--org", default="", help="organização (O)")
    g.add_argument("--unidade", default="", help="unidade organizacional (OU)")
    g.add_argument("--pais", default="BR", help="país com 2 letras (C)")
    g.add_argument("--estado", default="")
    g.add_argument("--cidade", default="")
    g.add_argument("--email", default="")
    g.add_argument("--bits", type=int, default=2048, help="tamanho da chave RSA (mínimo 2048)")
    g.add_argument("--dias", type=int, default=365, help="validade em dias")
    g.add_argument("--pasta", default="certificados", help="pasta de saída")
    g.add_argument("--prefixo", help="nome base dos arquivos gerados")
    g.set_defaults(func=cmd_gerar)

    a = sub.add_parser("assinar", help="assina digitalmente um PDF")
    a.add_argument("pdf")
    a.add_argument("--certificado", required=True, help="arquivo .p12 com chave privada e certificado")
    a.add_argument("--saida", help="PDF de saída (padrão: <nome>_assinado.pdf)")
    a.add_argument("--motivo", help="motivo da assinatura")
    a.add_argument("--local", help="local da assinatura")
    a.set_defaults(func=cmd_assinar)

    v = sub.add_parser("validar", help="valida as assinaturas de um PDF")
    v.add_argument("pdf")
    v.add_argument("--confiar", action="append", metavar="CERT.crt",
                   help="certificado de raiz confiável (pode repetir)")
    v.add_argument("--json", action="store_true", help="saída em JSON")
    v.set_defaults(func=cmd_validar)

    d = sub.add_parser("adulterar", help="altera um PDF assinado para testar a detecção de alterações")
    d.add_argument("pdf")
    d.add_argument("--modo", choices=["texto", "byte", "anexar"], default="texto")
    d.add_argument("--de", help="(modo texto) texto original")
    d.add_argument("--para", help="(modo texto) novo texto, com o mesmo tamanho")
    d.add_argument("--saida")
    d.set_defaults(func=cmd_adulterar)

    sub.add_parser("menu", help="menu interativo").set_defaults(func=lambda _a: menu())
    return p


def main(argv=None) -> int:
    args = criar_parser().parse_args(argv)
    if not getattr(args, "func", None):
        return menu()
    try:
        return args.func(args)
    except (ErroCertificado, ErroAssinatura, ErroAdulteracao, ValueError, OSError) as e:
        print(f"Erro: {e}", file=sys.stderr)
        return 2
