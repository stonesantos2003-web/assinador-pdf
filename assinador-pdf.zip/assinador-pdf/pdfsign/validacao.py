"""Funcionalidades 3 e 4 — validação de assinaturas, verificação de certificado e detecção de alterações.

São feitas TRÊS verificações independentes para cada assinatura:
  1. Criptográfica: o hash do documento confere com o assinado? A assinatura RSA confere com a chave pública?
  2. Integridade: o arquivo foi modificado dentro ou depois da área coberta pela assinatura?
  3. Confiança do certificado: é confiável, autoassinado ou de cadeia desconhecida?
"""
from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import re
from dataclasses import dataclass, field
from pathlib import Path

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, padding, rsa

from . import der

OID_SIGNED_DATA = "1.2.840.113549.1.7.2"
OID_MESSAGE_DIGEST = "1.2.840.113549.1.9.4"
OID_SIGNING_TIME = "1.2.840.113549.1.9.5"
OID_RSA_PSS = "1.2.840.113549.1.1.10"

HASHES = {
    "1.3.14.3.2.26": ("sha1", hashes.SHA1),
    "2.16.840.1.101.3.4.2.4": ("sha224", hashes.SHA224),
    "2.16.840.1.101.3.4.2.1": ("sha256", hashes.SHA256),
    "2.16.840.1.101.3.4.2.2": ("sha384", hashes.SHA384),
    "2.16.840.1.101.3.4.2.3": ("sha512", hashes.SHA512),
}


@dataclass
class InfoCertificado:
    titular: str
    emissor: str
    serie: str
    valido_de: str
    valido_ate: str
    sha256: str
    algoritmo_chave: str
    tamanho_chave: int | None
    usos_chave: list[str]
    autoassinado: bool


@dataclass
class ResultadoAssinatura:
    indice: int
    byte_range: list[int]
    subfiltro: str | None = None
    motivo: str | None = None
    hash_algoritmo: str | None = None
    data_assinatura: str | None = None
    certificado: InfoCertificado | None = None
    estrutura_ok: bool = False
    resumo_hash_confere: bool | None = None
    assinatura_confere: bool | None = None
    assinatura_valida: bool = False
    cobre_documento_inteiro: bool = False
    bytes_apos_assinatura: int = 0
    integridade: str = "indeterminada"   # integro | alterado_apos_assinatura | conteudo_alterado | assinatura_invalida | indeterminada
    confianca: str = "indeterminada"     # confiavel | autoassinado | cadeia_desconhecida | indeterminada
    cadeia: list[str] = field(default_factory=list)
    vigente_na_assinatura: bool | None = None
    avisos: list[str] = field(default_factory=list)
    erros: list[str] = field(default_factory=list)


# ----------------------------------------------------------------------------------------------
# Certificados
# ----------------------------------------------------------------------------------------------
def nome_legivel(nome: x509.Name) -> str:
    """Formata um nome X.509 como 'CN=Maria, O=UFX, C=BR' (e-mail como E=)."""
    rotulos = {"1.2.840.113549.1.9.1": "E"}
    partes = []
    for attr in nome:
        rot = rotulos.get(attr.oid.dotted_string) or attr.rfc4514_attribute_name
        partes.append(f"{rot}={attr.value}")
    return ", ".join(reversed(partes))


def _fingerprint(c: x509.Certificate) -> str:
    return c.fingerprint(hashes.SHA256()).hex().upper()


def _autoassinado(c: x509.Certificate) -> bool:
    if c.issuer != c.subject:
        return False
    try:
        c.verify_directly_issued_by(c)
        return True
    except Exception:
        return False


def descrever_certificado(c: x509.Certificate) -> InfoCertificado:
    pub = c.public_key()
    if isinstance(pub, rsa.RSAPublicKey):
        alg, bits = "RSA", pub.key_size
    elif isinstance(pub, ec.EllipticCurvePublicKey):
        alg, bits = f"EC ({pub.curve.name})", pub.key_size
    else:
        alg, bits = type(pub).__name__, None
    usos: list[str] = []
    try:
        ku = c.extensions.get_extension_for_class(x509.KeyUsage).value
        nomes = {
            "digital_signature": "assinatura digital", "content_commitment": "não repúdio",
            "key_encipherment": "cifragem de chaves", "data_encipherment": "cifragem de dados",
            "key_agreement": "acordo de chaves", "key_cert_sign": "assinar certificados", "crl_sign": "assinar CRL",
        }
        usos = [rot for attr, rot in nomes.items() if getattr(ku, attr)]
    except x509.ExtensionNotFound:
        pass
    return InfoCertificado(
        titular=nome_legivel(c.subject),
        emissor=nome_legivel(c.issuer),
        serie=format(c.serial_number, "X"),
        valido_de=c.not_valid_before_utc.isoformat(),
        valido_ate=c.not_valid_after_utc.isoformat(),
        sha256=_fingerprint(c),
        algoritmo_chave=alg,
        tamanho_chave=bits,
        usos_chave=usos,
        autoassinado=_autoassinado(c),
    )


def avaliar_confianca(cert, embutidos, raizes_confiaveis):
    """Devolve (status, cadeia). status: confiavel | autoassinado | cadeia_desconhecida."""
    confiaveis = {_fingerprint(r) for r in raizes_confiaveis}
    candidatos = list(raizes_confiaveis) + list(embutidos)
    cadeia = [cert]
    atual = cert
    for _ in range(10):
        if _fingerprint(atual) in confiaveis:
            return "confiavel", cadeia
        if _autoassinado(atual):
            return ("autoassinado" if len(cadeia) == 1 else "cadeia_desconhecida"), cadeia
        emissor = None
        for c in candidatos:
            if c.subject == atual.issuer:
                try:
                    atual.verify_directly_issued_by(c)
                    emissor = c
                    break
                except Exception:
                    continue
        if emissor is None:
            return "cadeia_desconhecida", cadeia
        cadeia.append(emissor)
        atual = emissor
    return "cadeia_desconhecida", cadeia


# ----------------------------------------------------------------------------------------------
# CMS / PKCS#7
# ----------------------------------------------------------------------------------------------
def _tempo_asn1(no: der.No) -> dt.datetime | None:
    txt = no.conteudo().decode("ascii", "ignore")
    try:
        if no.tag == 0x17:   # UTCTime
            fmt = "%y%m%d%H%M%S" if len(txt) >= 13 else "%y%m%d%H%M"
            return dt.datetime.strptime(txt.rstrip("Z")[: 12 if len(txt) >= 13 else 10], fmt).replace(tzinfo=dt.timezone.utc)
        if no.tag == 0x18:   # GeneralizedTime
            return dt.datetime.strptime(txt[:14], "%Y%m%d%H%M%S").replace(tzinfo=dt.timezone.utc)
    except ValueError:
        return None
    return None


def _achar_certificado_signatario(sid: der.No, certs: list[x509.Certificate]):
    if sid.tag == 0x30:  # IssuerAndSerialNumber
        emissor_der = sid.filhos[0].bruto()
        serie = int.from_bytes(sid.filhos[1].conteudo(), "big", signed=True)
        for c in certs:
            if c.serial_number == serie and c.issuer.public_bytes() == emissor_der:
                return c
    elif sid.tag == 0x80:  # SubjectKeyIdentifier
        ski = sid.conteudo()
        for c in certs:
            try:
                if c.extensions.get_extension_for_class(x509.SubjectKeyIdentifier).value.digest == ski:
                    return c
            except x509.ExtensionNotFound:
                continue
    return None


def _verificar_assinatura(cert, sig: bytes, dados: bytes, hash_cls, alg_oid: str) -> bool:
    pub = cert.public_key()
    try:
        if isinstance(pub, rsa.RSAPublicKey):
            if alg_oid == OID_RSA_PSS:
                pub.verify(sig, dados, padding.PSS(mgf=padding.MGF1(hash_cls()), salt_length=padding.PSS.AUTO), hash_cls())
            else:
                pub.verify(sig, dados, padding.PKCS1v15(), hash_cls())
        elif isinstance(pub, ec.EllipticCurvePublicKey):
            pub.verify(sig, dados, ec.ECDSA(hash_cls()))
        else:
            raise ValueError("Algoritmo de chave pública não suportado")
        return True
    except InvalidSignature:
        return False


def _ler_texto_pdf(regiao: bytes, chave: bytes) -> str | None:
    m = re.search(re.escape(chave) + rb"\s*<([0-9A-Fa-f]+)>", regiao)
    if m:
        bruto = bytes.fromhex(m.group(1).decode())
        try:
            return bruto[2:].decode("utf-16-be") if bruto[:2] == b"\xfe\xff" else bruto.decode("latin-1")
        except UnicodeDecodeError:
            return None
    m = re.search(re.escape(chave) + rb"\s*\(((?:\\.|[^\\)])*)\)", regiao)
    return m.group(1).decode("latin-1") if m else None


def _validar_uma(dados: bytes, indice: int, m: re.Match, raizes) -> ResultadoAssinatura:
    a, b, c, d = (int(x) for x in m.groups())
    r = ResultadoAssinatura(indice=indice, byte_range=[a, b, c, d])
    n = len(dados)

    # metadados do dicionário da assinatura
    ini_obj = dados.rfind(b" obj", 0, m.start())
    fim_obj = dados.find(b"endobj", m.end())
    regiao = dados[max(ini_obj, 0): fim_obj if fim_obj > 0 else m.end() + 200]
    sub = re.search(rb"/SubFilter\s*/([A-Za-z0-9_.]+)", regiao)
    r.subfiltro = sub.group(1).decode() if sub else None
    r.motivo = _ler_texto_pdf(regiao, b"/Reason")

    # 1) estrutura do /ByteRange
    if a != 0 or not (0 < b < c <= n) or c + d > n:
        r.erros.append("/ByteRange inconsistente com o tamanho do arquivo.")
        return r
    lacuna = dados[b:c]
    if lacuna[:1] != b"<" or lacuna[-1:] != b">":
        r.erros.append("O /ByteRange não delimita corretamente o campo /Contents.")
        return r
    r.estrutura_ok = True

    # 2) trecho depois da área assinada
    r.bytes_apos_assinatura = n - (c + d)
    r.cobre_documento_inteiro = len(dados[c + d:].strip(b"\r\n \t\x00")) == 0

    # 3) interpreta o PKCS#7
    try:
        bruto = bytes.fromhex(lacuna[1:-1].decode("ascii"))
        raiz = der.ler(bruto)
        if der.oid(raiz.filhos[0]) != OID_SIGNED_DATA:
            raise ValueError("a estrutura não é um SignedData")
        sd = raiz.filhos[1].filhos[0]
        certs_no = next((f for f in sd.filhos if f.tag == 0xA0), None)
        signer_infos = [f for f in sd.filhos if f.tag == 0x31][-1]
        embutidos = [x509.load_der_x509_certificate(f.bruto()) for f in (certs_no.filhos if certs_no else [])]
        si = signer_infos.filhos[0].filhos
        sid, dig = si[1], si[2]
        pos = 3
        attrs = None
        if si[pos].tag == 0xA0:
            attrs = si[pos]
            pos += 1
        alg_assin = der.oid(si[pos].filhos[0])
        assinatura = si[pos + 1].conteudo()
        hash_oid = der.oid(dig.filhos[0])
    except Exception as e:
        r.erros.append(f"Estrutura PKCS#7 ilegível (assinatura corrompida ou adulterada): {e}")
        r.integridade = "assinatura_invalida"
        return r

    if hash_oid not in HASHES:
        r.erros.append(f"Algoritmo de hash não suportado ({hash_oid}).")
        return r
    nome_hash, hash_cls = HASHES[hash_oid]
    r.hash_algoritmo = nome_hash.upper()

    cert = _achar_certificado_signatario(sid, embutidos)
    if cert is None:
        r.erros.append("Certificado do signatário não encontrado dentro da assinatura.")
        r.integridade = "assinatura_invalida"
        return r
    r.certificado = descrever_certificado(cert)

    # 4) resumo (hash) do conteúdo coberto pela assinatura
    coberto = dados[:b] + dados[c:c + d]
    calculado = hashlib.new(nome_hash, coberto).digest()
    atributos = {}
    if attrs is not None:
        for attr in attrs.filhos:
            atributos[der.oid(attr.filhos[0])] = attr.filhos[1].filhos[0]
        if OID_MESSAGE_DIGEST in atributos:
            r.resumo_hash_confere = hmac.compare_digest(calculado, atributos[OID_MESSAGE_DIGEST].conteudo())
        else:
            r.erros.append("Atributo messageDigest ausente.")
        if OID_SIGNING_TIME in atributos:
            t = _tempo_asn1(atributos[OID_SIGNING_TIME])
            if t:
                r.data_assinatura = t.isoformat()
                r.vigente_na_assinatura = cert.not_valid_before_utc <= t <= cert.not_valid_after_utc
                if not r.vigente_na_assinatura:
                    r.avisos.append("O certificado não estava dentro do prazo de validade no momento da assinatura.")
        a_verificar = b"\x31" + attrs.bruto()[1:]  # atributos assinados são re-codificados como SET OF
    else:
        a_verificar = coberto
        r.resumo_hash_confere = True  # sem atributos, a assinatura cobre o conteúdo diretamente

    # 5) assinatura RSA/ECDSA sobre os atributos (que contêm o hash)
    try:
        r.assinatura_confere = _verificar_assinatura(cert, assinatura, a_verificar, hash_cls, alg_assin)
    except Exception as e:
        r.erros.append(f"Falha ao verificar a assinatura: {e}")
        r.assinatura_confere = False

    r.assinatura_valida = bool(r.resumo_hash_confere and r.assinatura_confere)

    # 6) conclusão sobre integridade
    if r.resumo_hash_confere is False:
        r.integridade = "conteudo_alterado"
    elif not r.assinatura_confere:
        r.integridade = "assinatura_invalida"
    elif not r.cobre_documento_inteiro:
        r.integridade = "alterado_apos_assinatura"
    else:
        r.integridade = "integro"

    # 7) confiança do certificado (independente da validade da assinatura)
    r.confianca, cadeia = avaliar_confianca(cert, embutidos, raizes)
    r.cadeia = [nome_legivel(c.subject) for c in cadeia]
    agora = dt.datetime.now(dt.timezone.utc)
    if cert.not_valid_after_utc < agora:
        r.avisos.append("O certificado expirou (a assinatura pode ter sido válida na época em que foi feita).")
    return r


def validar_pdf(caminho, raizes_confiaveis: list[x509.Certificate] | None = None) -> list[ResultadoAssinatura]:
    """Valida todas as assinaturas de um PDF. Lista vazia = o documento não possui assinaturas."""
    dados = Path(caminho).read_bytes()
    if dados.lstrip()[:5] != b"%PDF-":
        raise ValueError("O arquivo selecionado não é um PDF.")
    resultados = []
    padrao = re.compile(rb"/ByteRange\s*\[\s*(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*\]")
    for i, m in enumerate(padrao.finditer(dados), start=1):
        resultados.append(_validar_uma(dados, i, m, raizes_confiaveis or []))
    if len(resultados) > 1:
        for r in resultados[:-1]:
            if not r.cobre_documento_inteiro and r.integridade == "alterado_apos_assinatura":
                r.avisos.append("Há revisões posteriores; pode ser apenas outra assinatura aplicada depois desta.")
    return resultados
