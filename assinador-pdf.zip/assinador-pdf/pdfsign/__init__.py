"""Assinador e validador de PDFs com certificados X.509 (trabalho de Segurança de Software)."""

__version__ = "1.0.0"
