"""Funcionalidade 1 — geração de chaves RSA e certificados X.509 autoassinados."""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.serialization import pkcs12
from cryptography.x509.oid import NameOID

TAMANHO_MINIMO_CHAVE = 2048


class ErroCertificado(Exception):
    pass


@dataclass
class DadosTitular:
    nome_comum: str
    organizacao: str = ""
    unidade: str = ""
    pais: str = "BR"
    estado: str = ""
    cidade: str = ""
    email: str = ""


def _montar_nome(t: DadosTitular) -> x509.Name:
    if not t.nome_comum.strip():
        raise ErroCertificado("O nome do titular (CN) é obrigatório.")
    atributos = [(NameOID.COMMON_NAME, t.nome_comum)]
    if t.organizacao:
        atributos.append((NameOID.ORGANIZATION_NAME, t.organizacao))
    if t.unidade:
        atributos.append((NameOID.ORGANIZATIONAL_UNIT_NAME, t.unidade))
    if t.cidade:
        atributos.append((NameOID.LOCALITY_NAME, t.cidade))
    if t.estado:
        atributos.append((NameOID.STATE_OR_PROVINCE_NAME, t.estado))
    if t.pais:
        if len(t.pais) != 2:
            raise ErroCertificado("O país deve ter 2 letras (ex.: BR).")
        atributos.append((NameOID.COUNTRY_NAME, t.pais.upper()))
    if t.email:
        atributos.append((NameOID.EMAIL_ADDRESS, t.email))
    return x509.Name([x509.NameAttribute(oid, valor) for oid, valor in atributos])


def gerar_chave_rsa(bits: int = 2048) -> rsa.RSAPrivateKey:
    """Gera o par de chaves (a chave pública é derivada da privada)."""
    if bits < TAMANHO_MINIMO_CHAVE:
        raise ErroCertificado(f"Tamanho de chave inseguro: use no mínimo {TAMANHO_MINIMO_CHAVE} bits.")
    return rsa.generate_private_key(public_exponent=65537, key_size=bits)


def gerar_certificado_autoassinado(
    titular: DadosTitular,
    chave: rsa.RSAPrivateKey,
    dias_validade: int = 365,
) -> x509.Certificate:
    """Cria um certificado X.509 v3 em que emissor == titular, assinado com a própria chave privada."""
    if dias_validade < 1:
        raise ErroCertificado("A validade deve ser de pelo menos 1 dia.")
    nome = _montar_nome(titular)
    agora = dt.datetime.now(dt.timezone.utc)
    inicio = agora - dt.timedelta(minutes=5)  # tolerância a diferenças de relógio
    pub = chave.public_key()
    return (
        x509.CertificateBuilder()
        .subject_name(nome)
        .issuer_name(nome)  # autoassinado
        .public_key(pub)
        .serial_number(x509.random_serial_number())
        .not_valid_before(inicio)
        .not_valid_after(agora + dt.timedelta(days=dias_validade))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, content_commitment=True,  # content_commitment = não repúdio
                key_encipherment=False, data_encipherment=False, key_agreement=False,
                key_cert_sign=False, crl_sign=False, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(pub), critical=False)
        .sign(chave, hashes.SHA256())  # assinatura do certificado com SHA-256 + RSA
    )


def exportar_certificado(cert: x509.Certificate, caminho: str | Path) -> Path:
    """Exporta apenas o certificado PÚBLICO (PEM, extensão .crt)."""
    caminho = Path(caminho)
    caminho.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    return caminho


def exportar_pkcs12(cert, chave, caminho: str | Path, senha: str, nome: str = "assinatura") -> Path:
    """Exporta chave privada + certificado em PKCS#12 (.p12) protegido por senha. NUNCA versionar este arquivo."""
    if not senha:
        raise ErroCertificado("Defina uma senha para proteger a chave privada.")
    dados = pkcs12.serialize_key_and_certificates(
        name=nome.encode("utf-8"),
        key=chave,
        cert=cert,
        cas=None,
        encryption_algorithm=serialization.BestAvailableEncryption(senha.encode("utf-8")),
    )
    caminho = Path(caminho)
    caminho.write_bytes(dados)
    return caminho


def carregar_pkcs12(caminho: str | Path, senha: str):
    """Lê um .p12 e devolve (chave_privada, certificado)."""
    try:
        chave, cert, _ = pkcs12.load_key_and_certificates(Path(caminho).read_bytes(), senha.encode("utf-8"))
    except ValueError as e:
        raise ErroCertificado("Não foi possível abrir o arquivo .p12 (senha incorreta ou arquivo inválido).") from e
    if chave is None or cert is None:
        raise ErroCertificado("O arquivo .p12 não contém chave privada e certificado.")
    return chave, cert


def carregar_certificado(caminho: str | Path) -> x509.Certificate:
    """Lê um certificado público em PEM ou DER."""
    dados = Path(caminho).read_bytes()
    try:
        if b"-----BEGIN" in dados:
            return x509.load_pem_x509_certificate(dados)
        return x509.load_der_x509_certificate(dados)
    except ValueError as e:
        raise ErroCertificado(f"Certificado inválido: {caminho}") from e


def gerar_e_exportar(titular, bits, dias, pasta, prefixo, senha):
    """Fluxo completo da Funcionalidade 1. Devolve (caminho_crt, caminho_p12, certificado)."""
    pasta = Path(pasta)
    pasta.mkdir(parents=True, exist_ok=True)
    chave = gerar_chave_rsa(bits)
    cert = gerar_certificado_autoassinado(titular, chave, dias)
    crt = exportar_certificado(cert, pasta / f"{prefixo}.crt")
    p12 = exportar_pkcs12(cert, chave, pasta / f"{prefixo}.p12", senha, nome=titular.nome_comum)
    return crt, p12, cert
