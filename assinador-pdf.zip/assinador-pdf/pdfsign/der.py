"""Mini-leitor ASN.1 (DER/BER) usado para interpretar a estrutura CMS/PKCS#7 da assinatura.

A biblioteca `cryptography` sabe *criar* assinaturas PKCS#7, mas não sabe *lê-las*.
Por isso a validação interpreta a estrutura ASN.1 manualmente, o que também permite
mostrar cada etapa do processo (resumo hash, atributos assinados, assinatura RSA).
"""
from __future__ import annotations


class No:
    """Um elemento TLV (tag, tamanho, valor) do ASN.1."""

    __slots__ = ("tag", "ini", "cont_ini", "cont_fim", "fim", "filhos", "dados")

    def __init__(self, dados, tag, ini, cont_ini, cont_fim, fim, filhos):
        self.dados = dados
        self.tag = tag
        self.ini = ini
        self.cont_ini = cont_ini
        self.cont_fim = cont_fim
        self.fim = fim
        self.filhos = filhos

    def bruto(self) -> bytes:
        """Bytes completos do elemento (tag + tamanho + conteúdo)."""
        return self.dados[self.ini:self.fim]

    def conteudo(self) -> bytes:
        return self.dados[self.cont_ini:self.cont_fim]


def ler(dados: bytes, pos: int = 0) -> No:
    if pos + 2 > len(dados):
        raise ValueError("ASN.1 truncado")
    tag = dados[pos]
    if tag & 0x1F == 0x1F:
        raise ValueError("Tags ASN.1 longas não são suportadas")
    construido = bool(tag & 0x20)
    tam = dados[pos + 1]
    p = pos + 2
    filhos: list[No] = []

    if tam == 0x80:  # tamanho indefinido (BER)
        if not construido:
            raise ValueError("Tamanho indefinido em elemento primitivo")
        cont_ini = p
        while dados[p:p + 2] != b"\x00\x00":
            if p >= len(dados):
                raise ValueError("ASN.1 truncado")
            f = ler(dados, p)
            filhos.append(f)
            p = f.fim
        cont_fim, fim = p, p + 2
    else:
        if tam & 0x80:
            n = tam & 0x7F
            tam = int.from_bytes(dados[p:p + n], "big")
            p += n
        cont_ini, cont_fim = p, p + tam
        fim = cont_fim
        if cont_fim > len(dados):
            raise ValueError("ASN.1 truncado")
        if construido:
            q = cont_ini
            while q < cont_fim:
                f = ler(dados, q)
                filhos.append(f)
                q = f.fim
            if q != cont_fim:
                raise ValueError("ASN.1 inconsistente")
    return No(dados, tag, pos, cont_ini, cont_fim, fim, filhos)


def oid(no: No) -> str:
    """Converte um OBJECT IDENTIFIER para a notação '1.2.840...'."""
    b = no.conteudo()
    if not b:
        return ""
    partes = [b[0] // 40, b[0] % 40]
    val = 0
    for x in b[1:]:
        val = (val << 7) | (x & 0x7F)
        if not x & 0x80:
            partes.append(val)
            val = 0
    return ".".join(str(p) for p in partes)
