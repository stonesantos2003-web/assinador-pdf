"""Funcionalidade 2 — assinatura digital de PDF (PKCS#7 destacado, SubFilter adbe.pkcs7.detached).

Como funciona (resumo):
  1. A assinatura é acrescentada ao final do arquivo como uma *atualização incremental*,
     portanto os bytes originais do documento NÃO são alterados.
  2. Reserva-se um espaço (/Contents) para a assinatura e define-se /ByteRange, que lista
     os trechos do arquivo cobertos pela assinatura (tudo, exceto o próprio /Contents).
  3. Calcula-se o hash SHA-256 desses trechos e assina-se com a chave privada RSA,
     gerando uma estrutura CMS/PKCS#7 que inclui o certificado do signatário.
  4. A estrutura CMS (em hexadecimal) é gravada no espaço reservado.
"""
from __future__ import annotations

import datetime as dt
import io
import re
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.serialization import pkcs7
from cryptography.x509.oid import NameOID
from pypdf import PdfReader, PdfWriter
from pypdf.generic import ArrayObject, DictionaryObject, IndirectObject, NameObject, NumberObject

TAMANHO_RESERVADO = 16384  # bytes reservados para a estrutura PKCS#7 (cabe cadeias de certificados)
PLACEHOLDER_NUM = "0000000000"


class ErroAssinatura(Exception):
    pass


def _res(obj):
    return obj.get_object() if hasattr(obj, "get_object") else obj


def _hex_utf16(texto: str) -> str:
    return "<FEFF" + texto.encode("utf-16-be").hex().upper() + ">"


def _serializar(obj) -> bytes:
    buf = io.BytesIO()
    obj.write_to_stream(buf)
    return buf.getvalue()


def _ultimo_startxref(dados: bytes) -> int:
    achados = re.findall(rb"startxref\s+(\d+)", dados)
    if not achados:
        raise ErroAssinatura("Arquivo PDF inválido: 'startxref' não encontrado.")
    return int(achados[-1])


def _xref_classico(dados: bytes) -> bool:
    try:
        pos = _ultimo_startxref(dados)
    except ErroAssinatura:
        return False
    return dados[pos:pos + 20].lstrip().startswith(b"xref")


def _normalizar(leitor: PdfReader) -> bytes:
    """PDFs com xref em fluxo (PDF 1.5+) são regravados com tabela xref clássica antes de assinar."""
    escritor = PdfWriter(clone_from=leitor)
    buf = io.BytesIO()
    escritor.write(buf)
    dados = buf.getvalue()
    if not _xref_classico(dados):
        raise ErroAssinatura("Não foi possível converter o PDF para tabela xref clássica.")
    return dados


def assinar_pdf(entrada, saida, chave, cert, motivo: str = "", local: str = "") -> dict:
    """Assina `entrada` e grava o PDF assinado em `saida`. Devolve informações da assinatura."""
    dados = Path(entrada).read_bytes()
    if not dados.lstrip()[:5] == b"%PDF-":
        raise ErroAssinatura("O arquivo selecionado não é um PDF.")
    try:
        leitor = PdfReader(io.BytesIO(dados))
    except Exception as e:  # pypdf lança vários tipos de erro
        raise ErroAssinatura(f"Não foi possível ler o PDF: {e}") from e
    if leitor.is_encrypted:
        raise ErroAssinatura("PDFs criptografados não são suportados.")
    if not _xref_classico(dados):
        dados = _normalizar(leitor)
        leitor = PdfReader(io.BytesIO(dados))
    if not leitor.pages:
        raise ErroAssinatura("O PDF não possui páginas.")

    trailer = leitor.trailer
    raiz_ref = trailer.raw_get("/Root")
    raiz = _res(raiz_ref)
    pagina = leitor.pages[0]
    pagina_id = pagina.indirect_reference.idnum
    tamanho = int(trailer["/Size"])
    sig_id, widget_id = tamanho, tamanho + 1
    prev = _ultimo_startxref(dados)

    # --- catálogo: registra o campo de assinatura em /AcroForm ---
    acro = _res(raiz["/AcroForm"]) if "/AcroForm" in raiz else None
    campos = list(_res(acro["/Fields"])) if acro is not None and "/Fields" in acro else []
    nome_campo = f"Assinatura{len(campos) + 1}"
    campos.append(IndirectObject(widget_id, 0, leitor))
    novo_acro = DictionaryObject(acro) if acro is not None else DictionaryObject()
    novo_acro[NameObject("/Fields")] = ArrayObject(campos)
    novo_acro[NameObject("/SigFlags")] = NumberObject(3)  # SignaturesExist + AppendOnly
    nova_raiz = DictionaryObject(raiz)
    nova_raiz[NameObject("/AcroForm")] = novo_acro

    # --- página 1: referencia o widget (campo invisível) em /Annots ---
    anots = list(_res(pagina["/Annots"])) if "/Annots" in pagina else []
    anots.append(IndirectObject(widget_id, 0, leitor))
    nova_pagina = DictionaryObject(pagina)
    nova_pagina[NameObject("/Annots")] = ArrayObject(anots)

    # --- monta a atualização incremental ---
    buf = bytearray(dados)
    if not buf.endswith(b"\n"):
        buf += b"\n"
    offsets: dict[int, int] = {}

    def adicionar(idnum: int, corpo: bytes):
        offsets[idnum] = len(buf)
        buf.extend(f"{idnum} 0 obj\n".encode() + corpo + b"\nendobj\n")

    momento = dt.datetime.now(dt.timezone.utc)
    data_pdf = momento.strftime("D:%Y%m%d%H%M%S+00'00'")
    cn = cert.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
    nome_titular = cn[0].value if cn else cert.subject.rfc4514_string()
    partes = [
        "<< /Type /Sig /Filter /Adobe.PPKLite /SubFilter /adbe.pkcs7.detached",
        f"/ByteRange [0 {PLACEHOLDER_NUM} {PLACEHOLDER_NUM} {PLACEHOLDER_NUM}]",
        "/Contents <" + "0" * (2 * TAMANHO_RESERVADO) + ">",
        f"/M ({data_pdf}) /Name {_hex_utf16(nome_titular)}",
    ]
    if motivo:
        partes.append(f"/Reason {_hex_utf16(motivo)}")
    if local:
        partes.append(f"/Location {_hex_utf16(local)}")
    partes.append(">>")
    adicionar(sig_id, " ".join(partes).encode("ascii"))

    widget = (
        f"<< /Type /Annot /Subtype /Widget /FT /Sig /T ({nome_campo}) /V {sig_id} 0 R "
        f"/F 132 /Rect [0 0 0 0] /P {pagina_id} 0 R >>"
    )
    adicionar(widget_id, widget.encode("ascii"))
    adicionar(pagina_id, _serializar(nova_pagina))
    adicionar(raiz_ref.idnum, _serializar(nova_raiz))

    # --- tabela xref incremental + trailer ---
    pos_xref = len(buf)
    buf.extend(b"xref\n")
    for idnum in sorted(offsets):
        buf.extend(f"{idnum} 1\n{offsets[idnum]:010d} 00000 n \n".encode())
    t = [f"/Size {tamanho + 2}", f"/Root {raiz_ref.idnum} 0 R", f"/Prev {prev}"]
    if "/Info" in trailer:
        t.append(f"/Info {trailer.raw_get('/Info').idnum} 0 R")
    trailer_bytes = b"trailer\n<< " + " ".join(t).encode()
    if "/ID" in trailer:
        trailer_bytes += b" /ID " + _serializar(trailer["/ID"])
    buf.extend(trailer_bytes + b" >>\n" + f"startxref\n{pos_xref}\n%%EOF\n".encode())

    # --- define o /ByteRange (tudo menos o /Contents) ---
    base = offsets[sig_id]
    ini_contents = buf.index(b"/Contents <", base) + len(b"/Contents ")  # posição do '<'
    fim_contents = ini_contents + 1 + 2 * TAMANHO_RESERVADO + 1          # posição logo após o '>'
    br = [0, ini_contents, fim_contents, len(buf) - fim_contents]
    pos_br = buf.index(b"/ByteRange [", base)
    antigo = f"/ByteRange [0 {PLACEHOLDER_NUM} {PLACEHOLDER_NUM} {PLACEHOLDER_NUM}]".encode()
    novo = f"/ByteRange [0 {br[1]:010d} {br[2]:010d} {br[3]:010d}]".encode()
    assert buf[pos_br:pos_br + len(antigo)] == antigo and len(antigo) == len(novo)
    buf[pos_br:pos_br + len(novo)] = novo

    # --- hash + assinatura RSA (CMS/PKCS#7 destacado, SHA-256) ---
    a_assinar = bytes(buf[:br[1]]) + bytes(buf[br[2]:])
    cms = (
        pkcs7.PKCS7SignatureBuilder()
        .set_data(a_assinar)
        .add_signer(cert, chave, hashes.SHA256())
        .sign(serialization.Encoding.DER, [pkcs7.PKCS7Options.DetachedSignature, pkcs7.PKCS7Options.Binary])
    )
    if len(cms) > TAMANHO_RESERVADO:
        raise ErroAssinatura("A assinatura excede o espaço reservado no PDF.")
    hexa = cms.hex().upper().encode("ascii")
    buf[ini_contents + 1: ini_contents + 1 + len(hexa)] = hexa

    Path(saida).write_bytes(bytes(buf))
    return {
        "saida": str(saida),
        "campo": nome_campo,
        "byte_range": br,
        "tamanho_pkcs7": len(cms),
        "data": momento.isoformat(),
    }
