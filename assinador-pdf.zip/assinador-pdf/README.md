# Assinador e Validador Digital de PDFs

Trabalho prático de **Segurança de Software** — aplicação de linha de comando (Python) que gera certificados
X.509, assina PDFs com assinatura digital padrão (PKCS#7 / `adbe.pkcs7.detached`), valida assinaturas e detecta
alterações no documento.

## Integrantes do grupo

| Nome | Matrícula |
|------|-----------|
| _Aluno 1_ | _000000_ |
| _Aluno 2_ | _000000_ |
| _Aluno 3_ | _000000_ |

## O que a aplicação faz

| # | Funcionalidade | Comando |
|---|----------------|---------|
| 1 | Gera par de chaves **RSA (mín. 2048 bits)** e certificado **X.509 autoassinado** (dados do titular, validade, exportação `.crt` público e `.p12` protegido por senha) | `gerar-certificado` |
| 2 | Assina um PDF (assinatura **real**, incorporada, verificável no Adobe Acrobat Reader) preservando o conteúdo original | `assinar` |
| 3 | Valida: identifica assinaturas, mostra o certificado, verifica hash + assinatura RSA, detecta alterações e classifica a confiança do certificado | `validar` |
| 4 | Verificação de integridade: altera um PDF já assinado e demonstra a detecção | `adulterar` + `validar` |

A validação informa **três coisas separadas**: (1) assinatura criptograficamente válida/inválida;
(2) integridade do documento (íntegro, conteúdo alterado ou alterado após a assinatura);
(3) confiança do certificado (confiável, autoassinado ou cadeia não reconhecida).

## Instalação

Requer **Python 3.10+**.

```bash
git clone <URL-DO-REPOSITORIO>
cd assinador-pdf
python -m venv .venv
# Linux/macOS:  source .venv/bin/activate
# Windows:      .venv\Scripts\activate
pip install -r requirements.txt
# opcional (gerar o PDF de exemplo e rodar os testes):
pip install -r requirements-dev.txt
```

## Execução

### Menu interativo (ideal para a apresentação)

```bash
python main.py
```

### Linha de comando

```bash
# 1) Gerar certificado (pede uma senha para proteger a chave privada)
python main.py gerar-certificado --nome "Maria Silva" --org "Minha Faculdade" --email maria@exemplo.com --dias 365 --bits 2048

# 2) Assinar um PDF (gera contrato_assinado.pdf)
python main.py assinar exemplos/contrato_exemplo.pdf --certificado certificados/maria_silva.p12 --motivo "Aprovação" --local "Rio Verde - GO"

# 3) Validar
python main.py validar exemplos/contrato_exemplo_assinado.pdf
python main.py validar exemplos/contrato_exemplo_assinado.pdf --confiar exemplos/certificado_exemplo.crt   # trata o certificado como raiz confiável
python main.py validar exemplos/contrato_exemplo_assinado.pdf --json                                      # saída em JSON

# 4) Adulterar e validar de novo
python main.py adulterar exemplos/contrato_exemplo_assinado.pdf --modo texto --de 1000,00 --para 9999,99
python main.py validar exemplos/contrato_exemplo_assinado_adulterado.pdf     # (nome gerado automaticamente)
python main.py adulterar exemplos/contrato_exemplo_assinado.pdf --modo anexar   # conteúdo acrescentado após a assinatura
```

A senha do `.p12` é pedida no terminal sem ecoar. Para automação, use a variável de ambiente `PDFSIGN_SENHA`.
Código de saída de `validar`: `0` tudo ok · `1` assinatura inválida ou documento alterado · `2` sem assinaturas/erro.

### Testes automatizados

```bash
python -m unittest discover -s tests -v
```

## Como funciona (resumo técnico)

1. **Certificado**: gera-se um par RSA; o certificado X.509 v3 (emissor = titular) é assinado com a própria chave
   privada (SHA-256). Extensões: `BasicConstraints`, `KeyUsage` (assinatura digital + não repúdio) e `SubjectKeyIdentifier`.
2. **Assinatura**: a assinatura é gravada como **atualização incremental** no fim do PDF (o original não é alterado).
   Reserva-se o campo `/Contents` e define-se o `/ByteRange` — os trechos do arquivo cobertos pela assinatura
   (tudo, exceto o próprio `/Contents`). Calcula-se o **SHA-256** desses trechos e a **chave privada** assina esse hash
   (CMS/PKCS#7 destacado, com o certificado embutido).
3. **Validação**: refaz o hash dos trechos indicados no `/ByteRange` e compara com o `messageDigest` assinado;
   verifica a assinatura RSA com a **chave pública** do certificado embutido; confere se o `/ByteRange` cobre o arquivo
   inteiro (bytes extras = alteração posterior); por fim avalia a cadeia do certificado.
4. O PKCS#7 é interpretado por um leitor ASN.1 próprio (`pdfsign/der.py`) e as operações criptográficas usam a
   biblioteca `cryptography`.

## Estrutura

```
main.py                 ponto de entrada
pdfsign/certificado.py  Funcionalidade 1 (chaves e X.509)
pdfsign/assinatura.py   Funcionalidade 2 (assinatura PDF/PKCS#7)
pdfsign/validacao.py    Funcionalidades 3 e 4 (validação, confiança, integridade)
pdfsign/adulteracao.py  utilitário para demonstrar a detecção de alterações
pdfsign/der.py          leitor ASN.1/DER
pdfsign/cli.py          comandos e menu interativo
tests/                  testes automatizados
exemplos/               PDFs de teste e certificado público de exemplo
docs/ROTEIRO_APRESENTACAO.md
```

## Exemplos incluídos (`exemplos/`)

- `contrato_exemplo.pdf` — PDF original · `contrato_exemplo_assinado.pdf` — assinado pela aplicação
- `contrato_exemplo_adulterado.pdf` — assinado e depois modificado (valor 1000,00 → 9999,99)
- `certificado_exemplo.crt` — certificado **público** do signatário de exemplo (a chave privada não foi publicada)

## Segurança

- Chaves privadas (`.p12`, `.key`, `.pem`) e a pasta `certificados/` estão no `.gitignore`. **Nunca** as publique.
- Certificados autoassinados aparecem no Adobe Reader como "identidade desconhecida/validade desconhecida" — é o
  comportamento esperado, pois não há uma AC reconhecida. Para ver a assinatura como válida no Adobe, importe o
  `.crt` em *Preferências → Assinaturas → Identidades e certificados confiáveis*.

## Limitações conhecidas

- Assinatura invisível (aparece no painel de assinaturas); PDFs criptografados não são suportados.
- PDFs com *xref stream* (PDF 1.5+) são regravados com tabela xref clássica antes de assinar (conteúdo preservado).
- Não há verificação de revogação (CRL/OCSP) nem carimbo de tempo.
