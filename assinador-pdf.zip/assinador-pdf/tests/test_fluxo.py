"""Testes automatizados do fluxo completo.  Execute:  python -m unittest discover -s tests -v"""
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

from pdfsign import adulteracao as adul  # noqa: E402
from pdfsign import assinatura, certificado, validacao  # noqa: E402

try:
    sys.path.insert(0, str(RAIZ / "exemplos"))
    from gerar_pdf_exemplo import gerar as gerar_pdf  # noqa: E402
except ImportError:  # reportlab é opcional (requirements-dev)
    gerar_pdf = None


@unittest.skipIf(gerar_pdf is None, "instale reportlab (requirements-dev.txt)")
class TestFluxo(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = Path(tempfile.mkdtemp())
        cls.pdf = Path(gerar_pdf(cls.tmp / "doc.pdf"))
        crt, p12, cls.cert = certificado.gerar_e_exportar(
            certificado.DadosTitular("Teste Automatizado", organizacao="UFX"), 2048, 30, cls.tmp, "teste", "senha")
        cls.chave, _ = certificado.carregar_pkcs12(p12, "senha")[0], None
        cls.assinado = cls.tmp / "assinado.pdf"
        assinatura.assinar_pdf(cls.pdf, cls.assinado, cls.chave, cls.cert, motivo="teste")

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def _unica(self, caminho, raizes=None):
        r = validacao.validar_pdf(caminho, raizes)
        self.assertEqual(len(r), 1)
        return r[0]

    def test_chave_minima_2048(self):
        with self.assertRaises(certificado.ErroCertificado):
            certificado.gerar_chave_rsa(1024)

    def test_certificado_autoassinado_rsa2048(self):
        self.assertEqual(self.cert.issuer, self.cert.subject)
        self.assertGreaterEqual(self.cert.public_key().key_size, 2048)

    def test_pdf_sem_assinatura(self):
        self.assertEqual(validacao.validar_pdf(self.pdf), [])

    def test_conteudo_original_preservado(self):
        orig, novo = self.pdf.read_bytes(), self.assinado.read_bytes()
        self.assertTrue(novo.startswith(orig))  # atualização incremental: bytes originais intactos

    def test_assinatura_valida_e_certificado_autoassinado(self):
        r = self._unica(self.assinado)
        self.assertTrue(r.assinatura_valida)
        self.assertEqual(r.integridade, "integro")
        self.assertEqual(r.confianca, "autoassinado")

    def test_certificado_confiavel_quando_informado(self):
        r = self._unica(self.assinado, [self.cert])
        self.assertEqual(r.confianca, "confiavel")
        self.assertTrue(r.assinatura_valida)

    def test_alteracao_de_conteudo_invalida_assinatura(self):
        alt = self.tmp / "alt.pdf"
        adul.adulterar_texto(self.assinado, alt, "1000,00", "9000,00")
        r = self._unica(alt)
        self.assertFalse(r.assinatura_valida)
        self.assertEqual(r.integridade, "conteudo_alterado")
        self.assertEqual(r.confianca, "autoassinado")  # confiança é avaliada separadamente

    def test_alteracao_de_um_bit(self):
        alt = self.tmp / "bit.pdf"
        adul.adulterar_byte(self.assinado, alt)
        self.assertFalse(self._unica(alt).assinatura_valida)

    def test_dados_acrescentados_apos_assinatura(self):
        alt = self.tmp / "anexo.pdf"
        adul.anexar_dados(self.assinado, alt)
        r = self._unica(alt)
        self.assertTrue(r.assinatura_valida)  # o trecho assinado continua íntegro...
        self.assertEqual(r.integridade, "alterado_apos_assinatura")  # ...mas o arquivo mudou depois
        self.assertFalse(r.cobre_documento_inteiro)

    def test_assinatura_corrompida(self):
        d = bytearray(self.assinado.read_bytes())
        i = d.index(b"/Contents <") + 11 + 400
        d[i] = ord("1") if d[i] != ord("1") else ord("2")
        alt = self.tmp / "sig.pdf"
        alt.write_bytes(bytes(d))
        self.assertFalse(self._unica(alt).assinatura_valida)

    def test_duas_assinaturas(self):
        _, p12, c2 = certificado.gerar_e_exportar(certificado.DadosTitular("Segundo"), 2048, 30, self.tmp, "seg", "x")
        k2, _ = certificado.carregar_pkcs12(p12, "x")
        dupla = self.tmp / "dupla.pdf"
        assinatura.assinar_pdf(self.assinado, dupla, k2, c2)
        r = validacao.validar_pdf(dupla)
        self.assertEqual(len(r), 2)
        self.assertTrue(all(x.assinatura_valida for x in r))

    @unittest.skipUnless(shutil.which("qpdf"), "qpdf não instalado")
    def test_pdf_com_xref_stream(self):
        xs = self.tmp / "xs.pdf"
        subprocess.run(["qpdf", "--object-streams=generate", str(self.pdf), str(xs)], check=True)
        out = self.tmp / "xs_assinado.pdf"
        assinatura.assinar_pdf(xs, out, self.chave, self.cert)
        self.assertTrue(self._unica(out).assinatura_valida)


if __name__ == "__main__":
    unittest.main()
