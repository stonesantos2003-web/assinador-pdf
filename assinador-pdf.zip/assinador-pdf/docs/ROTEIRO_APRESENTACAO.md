# Roteiro da apresentação prática (7 passos exigidos)

Rode `python main.py` (menu) ou os comandos do README.

1. **Gerar certificado** — opção 1 / `gerar-certificado`. Mostre o `.crt` (público) e o `.p12` (privado, com senha).
   Comando útil: `openssl x509 -in certificados/NOME.crt -text -noout`.
2. **Assinar um PDF** — opção 2 / `assinar`.
3. **Abrir no Adobe Acrobat Reader** — painel *Assinaturas*. Esperado: assinatura presente, "identidade desconhecida"
   (autoassinado). Dica: importe o `.crt` como identidade confiável para ver a marca verde.
4. **Validar na própria aplicação** — opção 3 / `validar`. Mostre titular, emissor, validade, SHA-256 e os 3 veredictos.
5. **Modificar o PDF após assinar** — opção 4 / `adulterar` (modo texto: `1000,00` → `9999,99`; ou modo anexar).
6. **Mostrar a detecção** — `validar` no arquivo adulterado: assinatura INVÁLIDA / conteúdo alterado,
   enquanto o certificado continua "autoassinado" (inválida ≠ não confiável). No modo *anexar*: assinatura válida,
   mas "alterado após a assinatura".
7. **Explicar o papel de cada elemento**:
   - **Hash (SHA-256)**: "impressão digital" do documento; qualquer bit alterado muda o hash.
   - **Chave privada**: cifra (assina) o hash/atributos; só o titular a possui.
   - **Chave pública**: dentro do certificado; qualquer um a usa para verificar a assinatura.
   - **Certificado X.509**: vincula a identidade do titular à chave pública (autoassinado = ele atesta a si mesmo,
     por isso não há cadeia de confiança).
   - **ByteRange**: indica exatamente quais bytes do PDF foram assinados (tudo, menos o campo da assinatura).

## Perguntas prováveis
- *Por que a assinatura é "incremental"?* Para preservar os bytes originais e permitir várias assinaturas.
- *Por que "inválida" é diferente de "não confiável"?* Validade = matemática (hash/assinatura); confiança = quem emitiu o certificado.
- *Onde fica o certificado?* Embutido no PKCS#7 dentro de `/Contents`.
- *Por que 2048 bits?* Mínimo atual aceito para RSA; menos que isso é considerado inseguro.
