"""Gera um PDF simples (sem compressão, para facilitar a demonstração de adulteração de texto)."""
import sys
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas


def gerar(caminho="exemplos/contrato_exemplo.pdf"):
    Path(caminho).parent.mkdir(parents=True, exist_ok=True)
    c = canvas.Canvas(str(caminho), pagesize=A4, pageCompression=0)
    c.setTitle("Contrato de exemplo")
    c.setFont("Helvetica-Bold", 18)
    c.drawString(72, 760, "CONTRATO DE PRESTACAO DE SERVICOS")
    c.setFont("Helvetica", 12)
    c.drawString(72, 720, "Contratante: Empresa Exemplo Ltda.")
    c.drawString(72, 700, "Contratado: Fulano de Tal")
    c.drawString(72, 680, "Valor total do contrato: R$ 1000,00")
    c.drawString(72, 660, "Este documento e apenas um exemplo para testes de assinatura digital.")
    c.save()
    return caminho


if __name__ == "__main__":
    print("PDF gerado em", gerar(*sys.argv[1:2]))
