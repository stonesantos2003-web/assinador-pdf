#!/usr/bin/env python3
"""Ponto de entrada: `python main.py` abre o menu; `python main.py --help` lista os comandos."""
import sys

from pdfsign.cli import main

if __name__ == "__main__":
    sys.exit(main())
